#include <stdio.h>
int main ()
{
	int a;
	printf ("Masukan Bilangan : ");
	scanf ("%d", &a);
	
	if (a>0){
		printf ("Bilangan Positif \n");
	}
	else{
		printf ("Bilangan Negatif \n");
	}
	return 0;
}
