#include <stdio.h>
#include <math.h>

int main (){
	int a;
	
	printf("Masukan Bilangan : ");
	scanf ("%d", &a);
	if (a%5==0){
		printf ("%d adalah kelipatan 5 \n", a);
	}
	else{
	if (a%5!=0)
		printf ("%d bukan kelipatan 5 \n", a);
	}
	return 0;
}
