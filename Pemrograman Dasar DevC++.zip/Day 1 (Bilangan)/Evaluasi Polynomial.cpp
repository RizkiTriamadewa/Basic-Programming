#include <stdio.h>

main ()
{
	printf("Program Evaluasi Polynomial\n");
	float x;
	printf ("masukan nilai x =", &x);
	scanf ("%f", &x);
	printf ("\nHasil dari 3x^2 - 5x + 6 = %f \n", 3 * x * x - 5 * x + 6);
}
