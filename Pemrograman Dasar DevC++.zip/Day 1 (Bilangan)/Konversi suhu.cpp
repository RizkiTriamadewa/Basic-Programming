#include <stdio.h>

int main ()
{
	printf ("Konversi suhu celcius ke fahrenheit\n");
	
	float celc, fahr;
	
	printf ("Input Suhu Celsius: ");
	scanf ("%f",&celc);
	printf ("\n");
	
	fahr= (1.8 * celc) + 32;
	
	printf ("%.2f Derajat Celcius = %.2f Derajat Fahrenheit \n" ,celc,fahr);
	return 0; 
}
