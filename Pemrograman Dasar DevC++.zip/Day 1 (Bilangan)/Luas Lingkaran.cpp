#include <stdio.h>
#include <conio.h>

int main(){
	float r, luas;
	
	printf ("Penghitung luas lingkaran\n\n");
	printf ("Masukan jari-jari :");
	scanf ("%f", &r);
	luas=3.14*r*r;
	
	printf ("Maka luas lingkaran: %f", luas);
	return 0;
}
