#include <stdio.h>

int main () {
	float uang;
	printf ("Masukan Jumlah Uang: ");
	scanf ("%f", &uang);
	
	float pertamax = 1500;
	float pertalite = 1000;
	float solar = 800;
	
	float l_pertamax = uang / pertamax;
	float l_pertalite = uang / pertalite;
	float l_solar = uang / solar;
	
	printf ("Jumlah bensin yang didapat dari uang sebesar %.2f\n", uang);
	printf ("harga pertamax adalah: %.2f liter\n", l_pertamax);
	printf ("harga pertalite adalah: %.2f liter\n", l_pertalite);
	printf ("harga solar adalah: %.2f liter\n", l_solar);
	
	return 0;
}
