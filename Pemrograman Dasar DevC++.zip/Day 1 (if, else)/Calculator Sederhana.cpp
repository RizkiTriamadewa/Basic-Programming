#include <stdio.h>

int main(){
	int b1,b2, pilihan;
	int hasilbagi, hasilkali, hasilkurang, hasiltambah;
	
	printf ("==> CALCULATOR SEDERHANA <== \n");
	printf ("Masukan Bilangan Pertama : ");
	scanf ("%i", &b1);
	printf ("Masukan Bilangan Kedua : ");
	scanf ("%i", &b2);
	
	printf ("Menu Matematika: \n");
	printf ("1. Penjumlahan \n");
	printf ("2. Pengurangan \n");
	printf ("3. Pembagian \n");
	printf ("4. Perkalian \n");
	printf ("Masukan pilihan (1-4) : ");
	scanf ("%i", &pilihan);
	
	if (pilihan==1){
		hasiltambah = b1+b2;
		printf ("Hasil Pertambahan : %i", hasiltambah);
	}
	else if (pilihan==2){
		hasilkurang = b1-b2;
		printf ("Hasil Pengurangan : %i", hasilkurang);
	}
	else if (pilihan==3){
		hasilbagi = b1/b2;
		printf ("Hasil Pembagian : %i", hasilbagi);
	}
	else if (pilihan==4){
		hasilkali = b1*b2;
		printf ("Hasil Perkalian : %i", hasilkali);
	}else{
		printf ("Pilihan salah");
	}
}
