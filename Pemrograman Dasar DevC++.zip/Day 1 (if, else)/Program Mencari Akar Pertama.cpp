#include <stdio.h>
#include <math.h>

int main(){
	float a,b,c,d,akar1,akar2;
	printf ("Bentuk persamaan kuadrat : ax2+bx+c=0 \n");
	printf ("Masukan Nilai A :");
	scanf ("%f", &a);
	printf ("Masukan Nilai B :");
	scanf ("%f", &b);
	printf ("Masukan Nilai C :");
	scanf ("%f", &c);
	
	d=b*b-4*a*c;
	
	if (d==0){
		akar1=-b/2*a;
		akar2=-b/2*a;
		printf ("Akar pertamanya adalah : %.1f \n", akar1);
		printf ("Akar keduanya adalah : %.1f \n", akar2);
		
	}else if (d>0){
		akar1=(-b + sqrt(d)) / 2*a;
		akar2=(-b - sqrt(d)) / 2*a;
		printf ("Akar pertamanya adalah : %.1f \n", akar1);
		printf ("Akar keduanya adalah : %.1f \n", akar2);
	
	}else if (d<0){
		akar1=((-1*b)/(2*a))+(sqrt(abs(d))/(2*a));
		akar2=((-1*b)/(2*a))-(sqrt(abs(d))/(2*a));
		printf ("Akar pertamanya adalah : %.1f \n", akar1);
		printf ("Akar keduanya adalah : %.1f \n", akar2);
	}
}
