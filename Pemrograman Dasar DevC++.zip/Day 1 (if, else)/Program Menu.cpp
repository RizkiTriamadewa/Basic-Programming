#include <stdio.h>

int main(){
	int menu;
	float sisi, jari1, jari2, tinggi;
	float phi=3.14;
	
	printf ("\n Masukan Pilihan Anda (1-3) = ");
	scanf ("%d", &menu);
	
	printf ("Menu Pilihan \n");
	printf ("1. Menghitung Volume Kubus \n");
	printf ("2. Menghitung Luas Lingkaran \n");
	printf ("3. Menghitung Volume Silinder \n");
	
	switch (menu){
	case 1 :
		printf ("\n Masukan Sisi Kubus = ");
		scanf ("%f", &sisi);
		printf ("Volume Kubus = %1.f", sisi*sisi*sisi);
		break;
		
	case 2 :
		printf ("\n Masukan Panjang Jari-jari lingkaran = ");
		scanf ("%f", &jari1);
		printf ("\n luas lingkaran = %1.f", phi*jari1*jari1);
		break;
		
	case 3 :
		printf ("\n Masukan Panjang Jari-jari lingkaran = ");
		scanf ("%f", &jari2);
		printf ("Masukan tinggi silinder = ");
		scanf ("%f", &tinggi);
		printf ("Volume Silinder = %1.f", phi*jari2*jari2*tinggi);
		break;
		
	default :
		printf ("Menu yang anda pilih salah");
		break;
	}
}
