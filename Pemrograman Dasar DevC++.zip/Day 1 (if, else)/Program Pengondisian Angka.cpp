#include <stdio.h>

int main(){
	int n;
	printf ("masukan nilai N : ");
	scanf ("%i", &n);
	
	if (n>50){
	if (n>75){
		n = n-25;
		printf ("Hasil Nilai N : %i", n);
		
	}else{
		n = n-10;
		printf ("Hasil Nilai N : %i", n);
	}
	}else{
		n = n+10;
		printf ("Hasil Nilai N : %i", n);
	}
}
