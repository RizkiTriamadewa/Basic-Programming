#include <stdio.h>

int main(){
	float beli,bayar,diskon;
	printf ("Total Belanja : " );
	scanf ("%f", &beli);
	
	if (beli<100000){
		bayar=beli;
		printf ("Harga Total Belanja : %.1f", bayar);
		
	}else if (beli>=100000){
		diskon = beli * 0.05;
		bayar = beli - diskon;
		printf ("Harga Total Belanja : %.1f", bayar);
	}
}
