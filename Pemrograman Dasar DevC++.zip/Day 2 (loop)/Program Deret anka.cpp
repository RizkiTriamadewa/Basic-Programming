#include <stdio.h>
int main (){
	int i,n;
	n=10;
	
	printf ("\n DERET ANGKA \n");
	for ( i = 1; i <= n; i++){
		if (i % 2 == 1) {
			printf ("%d ", i);
		}else {
			printf ("* ");
		}
	}
	printf ("\n");
	
	for ( i = 1; i <= n; i++){
		if (i % 2 == 0) {
			printf ("%d ", i);
		}else {
			printf ("* ");
		}
	}
	printf ("\n");
	
	for ( i = 1; i <= n; i++){
		if (i % 2 == 1) {
			printf ("%d ", i);
		}else {
			printf ("* ");
		}
	}
	printf ("\n");
	
	for ( i = 1; i <= n; i++){
		if (i % 2 == 0) {
			printf ("%d ", i);
		}else {
			printf ("* ");
		}
	}
	printf ("\n");
	
	for ( i = 1; i <= n; i++){
		if (i <= 5) {
			printf ("* ");
		}else {
			printf ("%d ", i);
		}
	}
	printf ("\n");
	
	for ( i = 1; i <= n; i++){
		if (i <= 5) {
			printf ("%d ", i);
		}else {
			printf ("* ");
		}
	}
	printf ("\n");
	return 0;
}
