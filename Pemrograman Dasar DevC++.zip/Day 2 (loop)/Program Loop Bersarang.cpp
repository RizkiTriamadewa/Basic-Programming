#include <stdio.h>

int main(){
	int nilai;
	
	printf ("masukan nilai= ");
	scanf ("%i", &nilai);
	
	int i,j;
	for(i=1;i<=nilai;i++){
		for(j=1;j<=nilai;j++){
			printf("+");
		}
		printf ("\n");
	}
}

