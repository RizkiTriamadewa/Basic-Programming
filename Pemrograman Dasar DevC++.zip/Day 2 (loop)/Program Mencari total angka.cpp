#include <stdio.h>

int main(){
	int count = 1;
	float total = 0;
	char ulang;
	while (1){
		float bilangan;
		printf ("Masukan Bilangan Ke-%d :", count);
		scanf ("%f",&bilangan);
		total +=bilangan ;
		
		count++;
		
		printf ("Masukan Data Lagi [y/t]? ");
		scanf (" %c",&ulang);
		
		if (ulang != 'y'){
			break;
		}
	}
	printf ("Total Jumlah Angka Anda Adalah : %.0f",total);
}
