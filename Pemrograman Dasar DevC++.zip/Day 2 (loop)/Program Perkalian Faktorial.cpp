#include <stdio.h>

int main (){
	int n, i;
	
	printf ("Masukan nilai N = ");
	scanf ("%i", &n);
	
	for (i=1;i<=n;i++){
		printf ("%ix", i);
	}
}
