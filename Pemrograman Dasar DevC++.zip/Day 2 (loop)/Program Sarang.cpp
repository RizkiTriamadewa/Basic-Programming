#include <stdio.h>

int main (){
	int nilai;
	
	printf ("masukan nilai = ");
	scanf ("%d", &nilai);
	
	for (int i = 1; i <= nilai; i++){
		for (int j = 1; j <= nilai; j++){
			int angka = (i % 2 == 0) ? nilai - j + 1 : j;
			printf ("%d ", angka);
		}
		printf ("\n");
	}
	return 0;
}
