#include <stdio.h>
int main(){
	
	int i,j,k,c,a;
	
	printf("masukan nilai= ");
	scanf ("%i", &a);
	c=65;
	for(i=1;i<=a;i++){
		for(j=1;j<=(a-i);j++){
			printf(" ");
			k++;
		}
		for(k=j;k<=a;k++){
			printf("%1c", c);
			c++;
		}
		printf ("\n");
	}
}
