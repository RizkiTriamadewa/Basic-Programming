#include <stdio.h>
int main(){
	
	int i,j,k,n;
	
	printf("masukan nilai= ");
	scanf ("%i", &n);
	k=65;
	for(i=n;i>=1;i--){
		for(j=i;j<=n;j++){
			printf("%3c", k);
			k++;
		}
		printf ("\n");
	}
}
