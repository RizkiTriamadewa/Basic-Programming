#include <conio.h>
#include <iostream>
#include <string>
using namespace std;
int main()
{
	int n;
	string nama[10],status[10];
	int nilaip1[10];
	int nilaip2[10];
	int nilaip3[10];

	cout<<"Masukan Jumlah Data = ";
	cin>>n;
	cout<<endl;

	for (int i=0; i<n; i++) {
		cout<<endl;
		
		cout<<"Data ke-"<<i+1<<endl;
		cout<<"Masukan praktek1 = ";
		cin>>nilaip1[i];
		cout<<"Masukan praktek2 = ";
		cin>>nilaip2[i];
		cout<<"Masukan praktek3 = ";
		cin>>nilaip3[i];
	}
	cout<<endl;
	cout<<"DAFTAR NILAI MAHASISWA"<<endl;
	cout<<"--------------------------------------------"<<endl;
	cout<<"Mahasiswa    praktek2	praktek2   praktek3         "<<endl;
	cout<<"--------------------------------------------"<<endl;

	for (int i=0; i<n;i++) {
	cout<<i+1<<"		"<<nilaip2[i]<<"	   "<<nilaip2[i]<<"	       "<<nilaip3[i]<<endl;
	cout<<"--------------------------------------------"<<endl;
	}

getch();
}
