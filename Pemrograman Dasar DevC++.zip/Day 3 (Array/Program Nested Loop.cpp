
#include <stdio.h>
int main (){
	int a [15];
	int jum, i, x;
	jum = 0;
	for (i=1;i<=15;i++){
		printf("Masukan Bilangan ke- %i :",i);
		scanf("%i",&a[i]);
	}
	
	printf("Masukan nilai yang dicari : ");
	scanf("%i",&x);
	
	for(i=1; i<=15;i++){
		if (a[i]==x){
			jum = jum + 1;
		}
	}
	printf("Nilai %i, ada %i buah",x, jum);
}
