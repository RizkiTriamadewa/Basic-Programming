#include <stdio.h>
int main(){
	int a[10]= {22, 32, 5, 17, 21, 26, 29, 55, 19, 20};
	int i, j, n, x;
	
	i = 0;
	n = 0;
	while (i < 5) {
		j = 0;
		i++;
		while (j < i-1){
			printf("%3i ", a[n]);
			n++;
			j++;
		}
		printf("\n");
	}
	return 0;
}