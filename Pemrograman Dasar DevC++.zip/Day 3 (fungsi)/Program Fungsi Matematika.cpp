#include <stdio.h>

// Deklarasi fungsi
float calculateF(int numbers[]) {
    int max = numbers[0];
    for (int i = 1; i < 5; i++) {
        if (numbers[i] > max) {
            max = numbers[i];
        }
    }
    float F = max / 2.0;  // Konversi ke float agar pembagian menghasilkan bilangan desimal
    return F;
}

int main() {
    int numbers[5] = {3, 6, 7, 8, 0};
    
    // Panggil fungsi calculateF dan cetak hasilnya
    float result = calculateF(numbers);
    printf("Hasil perhitungan F: %.2f\n", result);
}
