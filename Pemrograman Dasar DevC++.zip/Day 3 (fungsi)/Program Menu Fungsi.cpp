A#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <cstdlib>
#include <math.h>

int pangkat(int n, int m);
int faktorial(int f);
float jumlah_total(int n_tahun, int m_perioda, float tabungan_tahunan, float bunga);
main()
{
 int x, f, n, m, p, n_tahun, m_perioda;
 float tabungan_tahunan,bunga,total_uang;

 printf("======================================\n");
 printf("%25s\n", "Program 4 Menu");
 printf("======================================\n\n");
 x=1;
 while(x<=100)
 {
 printf("======================================\n");
 printf("%24s", "Daftar Menu\n");
 printf("======================================\n");
 printf("1. Pangkat\n");
 printf("2. Faktorial\n");
 printf("3. Tabungan\n");
 printf("4. Exit Porgram\n");
 printf("======================================\n");


 printf("\nMasukkan Nomor Program : "); scanf("%d",&p);
 printf("\n");
 switch(p)
 {
 case 1: printf("======================================\n");
 printf("Menghitung Nilai Basis Pangkat Eksponen \n");
 printf("======================================\n");
 printf("\nMasukkan Nilai Basis : "); scanf("%d",&n);
 printf("\nMasukkan Nilai Eksponen : "); scanf("%d",&m);
 printf("\nHasil Dari %d^%d adalah %d \n\n", n, m, pangkat(n,m));
 break;


 case 2: printf("======================================\n");
 printf("%10s","Menghitung Nilai Faktorial \n");
 printf("======================================\n");
 printf("\nMasukkan Nilai Basis : "); scanf("%d",&n);
 printf("\nHasil Dari Faktorial %d! adalah : %d\n\n", n, faktorial(n));
 break;

 case 3: printf("======================================\n");
 printf("%30s","Menghitung Tabungan \n");
 printf("======================================\n");
 printf("\nBerapa Tahun Masa Penabungan : ");
 scanf("%d",&n_tahun);
 printf("\nBerapa kali pembayaran bunga dilakukan dalam setahun : ");
 scanf("%d",&m_perioda);
 printf("\nBerapa besarnya uang yang ditabung setiap tahun : ");
 scanf("%f",&tabungan_tahunan);
 printf("\nBerapa bunga setiap tahunnya : ");
 scanf("%f",&bunga);
 total_uang=jumlah_total(n_tahun,m_perioda,tabungan_tahunan,bunga);
 printf("\nJumlah total uang yang terkumpul Selama %d tahun adalah %f\n\n",n_tahun,total_uang);
 break;

 case 4 : exit(1); break;

 default:printf("===========================\n");
 printf("Anda Salah Memasukkan Angka\n\n");
 printf("===========================\n"); break; }
 }
 getchar();
 system("Pause");}

int pangkat(int n, int m)
{int I; int pkt = 1;
 if(m==0) return(1); if(m==1) return(n);
 if(m>0) { for(I=1; I<=m; I=I+1)
 pkt = pkt*n;
 return(pkt); }
 else return(0); }
int faktorial(int n)
{int I;
int fkt = 1; if(n==0) return(1); if(n==1) return(n);
if(n>0) { for(I=n; I>=1; I--)
 fkt = fkt*I;
 return(fkt); }
else return(0); }
float jumlah_total(int n_tahun, int m_perioda, float tabungan_tahunan, float bunga)
{ int i;
float total=0;
for(i=1;i<=n_tahun;i++)
total=total+pow((1.0+bunga/(100.0*m_perioda)),i*m_perioda);
return tabungan_tahunan*total; }
