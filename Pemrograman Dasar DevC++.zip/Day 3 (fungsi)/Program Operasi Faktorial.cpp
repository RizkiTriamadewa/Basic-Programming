#include <stdio.h>
#include <conio.h>
float fact(float n);
main()
{
 float n;

 printf("Masukkan Nilai faktorial = ");
 scanf("%g", &n);
 printf("Faktorial dari %g adalah = %g", n, fact(n));
 getch();
}
float fact(float n)
{
 if(n>1)return n*fact(n-1);
 else return 1;
}

