#include <stdio.h>
#include <iostream>

int main(){
    // calculator sederhana
    float a, b, hasil;
    
    // luas Segitiga
    int alas, tinggi;
    float luas;
    
    // Menampilkan Bilangan Ganjil Dan Bilangan Terbesar
    int i;
    int n;
    int bilanganGanjil = 0;
    int bilanganbesar = 0;

    // membuat Huruf dengan *
    using namespace std;
    
    // menu pilihan
    int Pilihan;
    
    printf("============================\n");
    printf("|Rizki Triamadewa|223443069|\n");
    printf("============================\n");
    printf("|\tMenu Pilihan       |\n");
    printf("============================\n");
    printf("\n");
    printf("1.(Kalkulator Sederhana)\n");
    printf("2.(Luas Segitiga)\n");
    printf("3.(Menampilkan Bilangan Ganjil Dan Bilangan Terbesar)\n");
    printf("4.(Membuat Huruf Dengan *)\n");
    printf("\n");
    printf("Memilih Menu Nomor? : ");
    scanf("%d", &Pilihan);
    
    if(Pilihan == 1){
        printf("Pilih Menu Kalkulator\n");
        printf("1.Penjumlahan\n");
        printf("2.Pengurangan\n");
        printf("3.Perkalian\n");
        printf("4.Pembagian\n");
        printf("masukkan pilihan : ");
        scanf("%d", &Pilihan);

        printf("Masukkan Bilangan a : ");// input a
        scanf("%f", &a);
        printf("Masukkan Bilangan b : ");// input b
        scanf("%f", &b);

        if (Pilihan == 1){
            hasil = a + b;
            printf("Hasil Penjumlahan a + b = %.2f\n", hasil);//output hasil bilangan a + b
        }else if(Pilihan == 2){
            hasil = a - b;
            printf("Hasil Pengurangan a - b = %.2f\n", hasil);//output hasil bilangan a - b
        }else if(Pilihan == 3){
            hasil = a * b;
            printf("Hasil Perkalian a * b = %.2f\n", hasil);//output hasil bilangan a * b
        }else if(Pilihan == 4){
            hasil = a / b;
            printf("Hasil Pembagian a / b = %.2f\n", hasil);//output hasil bilangan a / b
        }
    }else if(Pilihan == 2){
        printf("memilih luas segitiga\n");
        printf("Masukkan alas: ");
        scanf("%d", &alas);//input alas
        printf("Masukkan tinggi: ");
        scanf("%d", &tinggi);//input tinggi
        luas = 0.5 * alas * tinggi; // rumus mencari luas segitiga
        printf("Luas segitiga adalah %.f\n", luas); //output hasil luas segitiga

    }else if(Pilihan == 3){
        printf("Masukkan Banyaknya Bilangan : ");
        scanf("%d", &n);

        printf("Masukkan Bilangan ganjil : ");
        scanf("%d", &i);

        for(i = 1; i <= n; i++){
            if(i % 2 == 1){
                bilanganGanjil++;
            }
            if(i > bilanganbesar){
                bilanganbesar = i;
            }
        }
        printf("Banyaknya Bilangan Ganjil : %d\n", bilanganGanjil);
        printf("Bilangan Terbesar : %d\n", bilanganbesar);

    }else if(Pilihan == 4){
   	for(int y=1; y<=5; y++) //baris
	{ 
		for(int x=1; x<=5; x++) //kolom
		{ 
		if(y==3||y==1||x==1||x==5&&y<=3||y==x&&y>3) cout<<"*";
		else cout<<" "; //karakter spasi
		}
		cout<<endl;
	}
}
    return 0;
}

